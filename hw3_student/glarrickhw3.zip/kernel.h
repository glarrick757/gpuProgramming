#ifndef KERNEL_H
#define KERNEL_H


__global__ void k0( float* g_dataA, float* g_dataB, int pitch, int width ); 

#endif
